class CategoryModel {
  late String categoryName;
  late String imageUrl;

}
